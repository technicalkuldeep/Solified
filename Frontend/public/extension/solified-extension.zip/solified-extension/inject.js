// Solified Signer Firewall — MAIN world transaction interceptor.
//
// Wraps window.solana.signTransaction / signAllTransactions / signAndSendTransaction
// and Phantom's request method, so that BEFORE any signature is produced we:
//   1) Serialize the tx (base64)
//   2) POST it to /api/analyze-transaction
//   3) Render a blocking modal showing decoded actions + warnings
//   4) Allow the user to BLOCK or CONTINUE
//
// Strict requirements from spec:
//   - Never read or transmit private keys
//   - Never break wallet flow on errors (fail-open with a visible disclosure)
//   - Cache analysis for identical serialized tx (debounce duplicates)

(function () {
  if (window.__solifiedFirewallInstalled) return;
  window.__solifiedFirewallInstalled = true;

  const API_BASE = "https://solified.onrender.com/api";
  const ANALYSIS_CACHE = new Map(); // sha-ish key -> { ts, data }
  const CACHE_TTL_MS = 60_000;

  // ---------- helpers ----------
  function b64Encode(bytes) {
    let bin = "";
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  }

  function txToBase64(tx) {
    if (!tx) return null;
    try {
      // Both VersionedTransaction (.serialize()) and legacy Transaction (.serialize())
      if (typeof tx.serialize === "function") {
        const bytes = tx.serialize({ requireAllSignatures: false, verifySignatures: false });
        return b64Encode(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes));
      }
      if (tx instanceof Uint8Array) return b64Encode(tx);
      if (Array.isArray(tx) && typeof tx[0] === "number") return b64Encode(new Uint8Array(tx));
    } catch (e) {
      console.warn("[Solified] tx serialization failed:", e);
    }
    return null;
  }

  async function quickHash(s) {
    try {
      const buf = new TextEncoder().encode(s);
      const h = await crypto.subtle.digest("SHA-1", buf);
      return Array.from(new Uint8Array(h)).map((b) => b.toString(16).padStart(2, "0")).join("");
    } catch {
      return s.slice(0, 32);
    }
  }

  async function analyzeTx(b64, wallet, intent) {
    const key = await quickHash(b64 + (intent?.kind || ""));
    const cached = ANALYSIS_CACHE.get(key);
    if (cached && Date.now() - cached.ts < CACHE_TTL_MS) return cached.data;
    try {
      const r = await fetch(`${API_BASE}/analyze-transaction`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          transaction: b64,
          userWallet: wallet || null,
          intent: intent?.kind || null,
          intentDetail: intent?.raw || null,
        }),
      });
      const data = await r.json();
      ANALYSIS_CACHE.set(key, { ts: Date.now(), data });
      return data;
    } catch (e) {
      console.warn("[Solified] analyze-transaction failed:", e);
      return null;
    }
  }

  function getActiveWallet() {
    try {
      const sol = window.solana;
      if (sol && sol.publicKey) return sol.publicKey.toString();
    } catch {}
    return null;
  }

  // ---------- Intent capture ----------
  // Watch button/anchor clicks and remember the most recent label that looks
  // like a transaction-triggering action. This runs in MAIN world so it sees
  // the page's DOM directly.
  let lastIntent = null;
  let lastIntentAt = 0;
  const INTENT_WINDOW_MS = 8000;

  const INTENT_PATTERNS = [
    { re: /\bswap\b/i, kind: "swap" },
    { re: /\b(send|transfer)\b/i, kind: "send" },
    { re: /\bmint\b/i, kind: "mint" },
    { re: /\b(stake|delegate)\b/i, kind: "stake" },
    { re: /\b(approve|allow)\b/i, kind: "approve" },
    { re: /\bbuy\b/i, kind: "swap" },
    { re: /\bclaim\b/i, kind: "claim" },
  ];

  function classifyText(label) {
    if (!label) return null;
    const trimmed = label.trim().slice(0, 80);
    for (const p of INTENT_PATTERNS) {
      if (p.re.test(trimmed)) return { kind: p.kind, raw: trimmed };
    }
    return null;
  }

  document.addEventListener("click", (e) => {
    try {
      const target = e.target.closest("button, [role=button], a");
      if (!target) return;
      const text = (target.innerText || target.getAttribute("aria-label") || "").trim();
      const c = classifyText(text);
      if (c) {
        lastIntent = c;
        lastIntentAt = Date.now();
      }
    } catch {}
  }, true);

  function currentIntent() {
    if (!lastIntent) return null;
    if (Date.now() - lastIntentAt > INTENT_WINDOW_MS) return null;
    return lastIntent;
  }

  // ---------- modal ----------
  function colorFor(color) {
    if (color === "green") return "#00FF66";
    if (color === "yellow") return "#FFD600";
    return "#FF3333";
  }

  function ensureStyle() {
    if (document.getElementById("solified-fw-style")) return;
    const css = `
      .sfw-overlay { position: fixed; inset: 0; z-index: 2147483647;
        background: rgba(0,0,0,0.78); backdrop-filter: blur(6px);
        display:flex; align-items:center; justify-content:center; padding:24px;
        font-family: "IBM Plex Sans", -apple-system, BlinkMacSystemFont, sans-serif; color:#fff;
        animation: sfw-fade .18s ease-out; }
      @keyframes sfw-fade { from{opacity:0} to{opacity:1} }
      .sfw-modal { width:100%; max-width:560px; background:#0A0A0C; border:1px solid rgba(255,255,255,0.12);
        border-radius:0; padding:28px; box-shadow:0 30px 80px rgba(0,0,0,0.6); position:relative; }
      .sfw-modal[data-tone="red"] { border-left:4px solid #FF3333; }
      .sfw-modal[data-tone="yellow"] { border-left:4px solid #FFD600; }
      .sfw-modal[data-tone="green"] { border-left:4px solid #00FF66; }
      .sfw-eyebrow { font-family:"IBM Plex Mono", monospace; font-size:10px; letter-spacing:0.28em;
        color:rgba(255,255,255,0.5); text-transform:uppercase; display:flex; align-items:center; gap:8px; }
      .sfw-eyebrow .sfw-dot { width:8px; height:8px; }
      .sfw-title { margin-top:14px; font-family:"Azeret Mono","IBM Plex Mono",monospace; font-weight:900;
        font-size:26px; letter-spacing:-0.02em; line-height:1.05; }
      .sfw-meta { margin-top:8px; font-family:"IBM Plex Mono",monospace; font-size:11px; color:rgba(255,255,255,0.55);
        letter-spacing:.06em; }
      .sfw-section { margin-top:20px; padding-top:16px; border-top:1px solid rgba(255,255,255,0.08); }
      .sfw-section-title { font-family:"IBM Plex Mono",monospace; font-size:10px; letter-spacing:0.25em;
        color:rgba(255,255,255,0.45); text-transform:uppercase; }
      .sfw-actions { margin-top:10px; display:flex; flex-direction:column; gap:6px; }
      .sfw-action { padding:10px 12px; background:#121216; border:1px solid rgba(255,255,255,0.08);
        font-family:"IBM Plex Mono",monospace; font-size:12px; color:#fff; word-break:break-word; }
      .sfw-warns { margin-top:10px; display:flex; flex-direction:column; gap:8px; }
      .sfw-warn { padding:10px 12px; border-left:3px solid; font-family:"IBM Plex Sans",sans-serif; font-size:12px; }
      .sfw-warn[data-level="high"] { border-color:#FF3333; background:rgba(255,51,51,0.08); color:#FFB3B3; }
      .sfw-warn[data-level="medium"] { border-color:#FFD600; background:rgba(255,214,0,0.08); color:#FFE680; }
      .sfw-warn[data-level="low"] { border-color:rgba(255,255,255,0.2); background:rgba(255,255,255,0.04); color:rgba(255,255,255,0.7); }
      .sfw-warn b { color:#fff; display:block; margin-bottom:2px; font-size:11px; letter-spacing:.05em; text-transform:uppercase; }
      .sfw-buttons { margin-top:24px; display:flex; gap:10px; justify-content:flex-end; }
      .sfw-btn { padding:12px 18px; border-radius:0; font-family:"IBM Plex Mono",monospace; font-size:11px;
        font-weight:700; letter-spacing:.18em; text-transform:uppercase; cursor:pointer; transition: opacity .15s, background .15s; }
      .sfw-btn-block { background:#FF3333; color:#0A0A0C; border:1px solid #FF3333; }
      .sfw-btn-block:hover { opacity:.9; }
      .sfw-btn-continue { background:transparent; color:#fff; border:1px solid rgba(255,255,255,0.25); }
      .sfw-btn-continue:hover { border-color:#fff; }
      .sfw-score-row { display:flex; align-items:center; gap:14px; margin-top:6px; }
      .sfw-score { font-family:"Azeret Mono",monospace; font-weight:900; font-size:42px; line-height:1; letter-spacing:-0.03em; }
      .sfw-level { font-family:"IBM Plex Mono",monospace; font-size:11px; padding:3px 8px; border:1px solid currentColor;
        text-transform:uppercase; letter-spacing:.18em; }
      .sfw-program-list { display:flex; flex-wrap:wrap; gap:6px; margin-top:10px; }
      .sfw-program { font-family:"IBM Plex Mono",monospace; font-size:10px; padding:3px 8px;
        border:1px solid rgba(255,255,255,0.15); color:rgba(255,255,255,0.7); }
      .sfw-program[data-trusted="true"] { color:#00FF66; border-color:rgba(0,255,102,0.35); }
      .sfw-loading { display:flex; align-items:center; gap:10px; margin-top:8px; font-family:"IBM Plex Mono",monospace;
        font-size:11px; letter-spacing:.18em; text-transform:uppercase; color:rgba(255,255,255,0.5); }
      .sfw-spin { width:14px; height:14px; border:2px solid rgba(255,255,255,0.2); border-top-color:#fff;
        border-radius:50%; animation: sfw-spin .8s linear infinite; }
      @keyframes sfw-spin { to { transform: rotate(360deg); } }
    `;
    const el = document.createElement("style");
    el.id = "solified-fw-style";
    el.textContent = css;
    document.head.appendChild(el);
  }

  function showModal({ analysis, txBase64 }) {
    return new Promise((resolve) => {
      ensureStyle();
      const overlay = document.createElement("div");
      overlay.className = "sfw-overlay";

      const renderContent = (a) => {
        if (!a) {
          return `
            <div class="sfw-loading"><span class="sfw-spin"></span> Solifying transaction…</div>
          `;
        }
        const tone = a.riskColor || "yellow";
        const c = colorFor(tone);
        const actionHtml = (a.actions || [])
          .map((x) => `<div class="sfw-action">${escape(x)}</div>`)
          .join("") || `<div class="sfw-action">No human-readable actions decoded.</div>`;
        const warnHtml = (a.warnings || [])
          .map((w) => `<div class="sfw-warn" data-level="${w.level}"><b>${escape(w.label)}</b>${escape(w.detail || "")}</div>`)
          .join("") || `<div class="sfw-warn" data-level="low"><b>No warnings</b>Proceed at your own discretion.</div>`;
        const progHtml = (a.programs || [])
          .map((p) => `<span class="sfw-program" data-trusted="${!!p.trusted}">${escape(p.name || p.programId.slice(0, 8) + '…')}</span>`)
          .join("");
        return `
          <div class="sfw-modal" data-tone="${tone}">
            <div class="sfw-eyebrow">
              <span class="sfw-dot" style="background:${c}"></span>
              SOLIFIED · SIGNER FIREWALL
            </div>
            <div class="sfw-title" style="color:${c}">⚠ Solified Warning</div>
            <div class="sfw-meta">${a.instructionCount || 0} instruction(s) · ${a.version || "tx"} · ${a.programs?.length || 0} program(s)</div>
            <div class="sfw-score-row">
              <div class="sfw-score" style="color:${c}">${a.score ?? "—"}</div>
              <div class="sfw-level" style="color:${c}">${a.riskLevel || "Unknown"} Risk</div>
            </div>
            <div class="sfw-program-list">${progHtml}</div>

            <div class="sfw-section">
              <div class="sfw-section-title">What this transaction does</div>
              <div class="sfw-actions">${actionHtml}</div>
            </div>

            <div class="sfw-section">
              <div class="sfw-section-title">Warnings</div>
              <div class="sfw-warns">${warnHtml}</div>
            </div>

            <div class="sfw-buttons">
              <button class="sfw-btn sfw-btn-block" data-act="block">🚫 Block transaction</button>
              <button class="sfw-btn sfw-btn-continue" data-act="continue">✅ Continue anyway</button>
            </div>
          </div>
        `;
      };

      overlay.innerHTML = renderContent(analysis);
      document.body.appendChild(overlay);

      const wire = () => {
        overlay.querySelectorAll("[data-act]").forEach((btn) => {
          btn.addEventListener("click", () => {
            const act = btn.getAttribute("data-act");
            overlay.remove();
            resolve(act);
          });
        });
        overlay.addEventListener("click", (e) => {
          if (e.target === overlay) {
            overlay.remove();
            resolve("block"); // safe default: outside-click = block
          }
        });
      };

      if (analysis) {
        wire();
      } else {
        // Showed loading; caller will call updateModal
        overlay._update = (a) => {
          overlay.innerHTML = renderContent(a);
          wire();
        };
      }

      // Expose updater
      overlay._wire = wire;
    });
  }

  function escape(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // ---------- gating logic ----------
  async function gateTransaction(tx) {
    const b64 = txToBase64(tx);
    if (!b64) return "continue"; // unknown payload, fail-open with banner
    const wallet = getActiveWallet();
    const intent = currentIntent();

    // Show modal with loader, fetch analysis, then update.
    let resolveDecision;
    const decisionPromise = new Promise((res) => (resolveDecision = res));
    const overlay = document.createElement("div");
    ensureStyle();
    overlay.className = "sfw-overlay";
    overlay.innerHTML = `
      <div class="sfw-modal" data-tone="yellow">
        <div class="sfw-eyebrow"><span class="sfw-dot" style="background:#FFD600"></span> SOLIFIED · SIGNER FIREWALL</div>
        <div class="sfw-title">Inspecting transaction…</div>
        <div class="sfw-loading"><span class="sfw-spin"></span> Decoding & simulating</div>
      </div>
    `;
    document.body.appendChild(overlay);

    const analysis = await analyzeTx(b64, wallet, intent);

    // If analysis failed entirely, fail-open with informational modal
    const finalAnalysis = analysis || {
      score: null,
      riskLevel: "Unknown",
      riskColor: "yellow",
      actions: ["Could not decode transaction details."],
      warnings: [{ level: "medium", label: "Solified analysis unavailable", detail: "Backend did not return a verdict. Proceed only if you fully trust the dApp." }],
      programs: [],
      instructionCount: 0,
      version: "tx",
    };

    const tone = finalAnalysis.riskColor || "yellow";
    const c = colorFor(tone);
    const actionHtml = (finalAnalysis.actions || [])
      .map((x) => `<div class="sfw-action">${escape(x)}</div>`)
      .join("") || `<div class="sfw-action">No human-readable actions decoded.</div>`;
    const warnHtml = (finalAnalysis.warnings || [])
      .map((w) => `<div class="sfw-warn" data-level="${w.level}"><b>${escape(w.label)}</b>${escape(w.detail || "")}</div>`)
      .join("") || `<div class="sfw-warn" data-level="low"><b>No warnings</b>Proceed at your own discretion.</div>`;
    const progHtml = (finalAnalysis.programs || [])
      .map((p) => `<span class="sfw-program" data-trusted="${!!p.trusted}">${escape(p.name || p.programId.slice(0, 8) + '…')}</span>`)
      .join("");

    const intentRow = finalAnalysis.intent
      ? `<div class="sfw-section">
          <div class="sfw-section-title">Intent vs Reality</div>
          <div class="sfw-action" style="margin-top:8px">
            <div style="font-size:10px;color:rgba(255,255,255,0.55);text-transform:uppercase;letter-spacing:.18em">Expected</div>
            <div style="margin-top:2px">${escape(finalAnalysis.intent.expected || finalAnalysis.intent.raw || "—")}</div>
          </div>
          <div class="sfw-action" style="margin-top:6px">
            <div style="font-size:10px;color:rgba(255,255,255,0.55);text-transform:uppercase;letter-spacing:.18em">Actual</div>
            <div style="margin-top:2px">${escape((finalAnalysis.intent.actual || []).join(" · ") || "—")}</div>
          </div>
          ${
            finalAnalysis.intent.mismatch
              ? `<div class="sfw-warn" data-level="high" style="margin-top:8px"><b>⚠ Mismatch</b>${escape(finalAnalysis.intent.mismatch)}</div>`
              : ""
          }
        </div>`
      : "";

    overlay.innerHTML = `
      <div class="sfw-modal" data-tone="${tone}">
        <div class="sfw-eyebrow"><span class="sfw-dot" style="background:${c}"></span> SOLIFIED · SIGNER FIREWALL</div>
        <div class="sfw-title" style="color:${c}">⚠ Solified Warning</div>
        <div class="sfw-meta">${finalAnalysis.instructionCount || 0} instruction(s) · ${finalAnalysis.version || "tx"} · ${finalAnalysis.programs?.length || 0} program(s)</div>
        <div class="sfw-score-row">
          <div class="sfw-score" style="color:${c}">${finalAnalysis.score ?? "—"}</div>
          <div class="sfw-level" style="color:${c}">${finalAnalysis.riskLevel || "Unknown"} Risk</div>
        </div>
        <div class="sfw-program-list">${progHtml}</div>
        ${intentRow}
        <div class="sfw-section">
          <div class="sfw-section-title">What this transaction does</div>
          <div class="sfw-actions">${actionHtml}</div>
        </div>
        <div class="sfw-section">
          <div class="sfw-section-title">Warnings</div>
          <div class="sfw-warns">${warnHtml}</div>
        </div>
        <div class="sfw-buttons">
          <button class="sfw-btn sfw-btn-block" data-act="block">🚫 Block transaction</button>
          <button class="sfw-btn sfw-btn-continue" data-act="continue">✅ Continue anyway</button>
        </div>
      </div>
    `;
    overlay.querySelectorAll("[data-act]").forEach((btn) => {
      btn.addEventListener("click", () => {
        overlay.remove();
        resolveDecision(btn.getAttribute("data-act"));
      });
    });
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) {
        overlay.remove();
        resolveDecision("block");
      }
    });

    return decisionPromise;
  }

  // ---------- wrapper installer ----------
  function wrapProvider(provider) {
    if (!provider || provider.__solifiedWrapped) return;
    provider.__solifiedWrapped = true;

    const origSign = provider.signTransaction?.bind(provider);
    const origSignAll = provider.signAllTransactions?.bind(provider);
    const origSignAndSend = provider.signAndSendTransaction?.bind(provider);

    if (origSign) {
      provider.signTransaction = async (tx, ...rest) => {
        try {
          const decision = await gateTransaction(tx);
          if (decision === "block") throw new Error("Blocked by Solified");
        } catch (err) {
          if (err && err.message === "Blocked by Solified") throw err;
          console.warn("[Solified] gate error, failing open:", err);
        }
        return origSign(tx, ...rest);
      };
    }

    if (origSignAll) {
      provider.signAllTransactions = async (txs, ...rest) => {
        try {
          // gate the FIRST tx; assume bundle is one logical operation.
          if (Array.isArray(txs) && txs.length) {
            const decision = await gateTransaction(txs[0]);
            if (decision === "block") throw new Error("Blocked by Solified");
          }
        } catch (err) {
          if (err && err.message === "Blocked by Solified") throw err;
          console.warn("[Solified] gate error, failing open:", err);
        }
        return origSignAll(txs, ...rest);
      };
    }

    if (origSignAndSend) {
      provider.signAndSendTransaction = async (tx, ...rest) => {
        try {
          const decision = await gateTransaction(tx);
          if (decision === "block") throw new Error("Blocked by Solified");
        } catch (err) {
          if (err && err.message === "Blocked by Solified") throw err;
          console.warn("[Solified] gate error, failing open:", err);
        }
        return origSignAndSend(tx, ...rest);
      };
    }

    console.log("[Solified] Signer Firewall armed on provider", provider?.isPhantom ? "(Phantom)" : provider?.isSolflare ? "(Solflare)" : "");
  }

  function tryArm() {
    const candidates = [];
    if (window.solana) candidates.push(window.solana);
    if (window.phantom?.solana) candidates.push(window.phantom.solana);
    if (window.solflare) candidates.push(window.solflare);
    candidates.forEach(wrapProvider);
  }

  tryArm();
  // Re-arm when wallets inject after page load
  let attempts = 0;
  const interval = setInterval(() => {
    tryArm();
    if (++attempts > 40) clearInterval(interval); // ~20s
  }, 500);

  // Allow manual demo from page console:
  window.solifiedDemo = async function () {
    return gateTransaction({
      serialize: () => new Uint8Array([0]), // empty stub triggers fail-open analysis
    });
  };
})();
